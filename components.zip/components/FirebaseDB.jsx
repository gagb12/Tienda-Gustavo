import React from 'react';
import ReactDOM from 'react-dom';
import * as firebase from 'firebase';

  const totalUsers : Object = [];
  const config = {
    apiKey: "AIzaSyA7fh-vTMNyf6FX1zQ88ZpBUVoe8fuhHG0",
    authDomain: "tienda-gustavo-angular2.firebaseapp.com",
    databaseURL: "https://tienda-gustavo-angular2.firebaseio.com",
    projectId: "tienda-gustavo-angular2",
    storageBucket: "tienda-gustavo-angular2.appspot.com",
    messagingSenderId: "995562120177",
    appId: "1:995562120177:web:deb6127ca342a305dc1a50",
    measurementId: "G-YNPCK7583D"
  };
  firebase.initializeApp(config);

const productosDB = firebase.database().ref().child('productos')
const usuariosDB = firebase.database().ref().child('usuarios')

usuariosDB.orderByChild("id").on("child_added", function(snapshot) {
  totalUsers.push(snapshot.key)
});
